// Select the login form and elements
const loginButton = document.getElementById('login-btn');
const logoutButton = document.getElementById('logoutButton');
const usernameField = document.getElementById('username');
const passwordField = document.getElementById('password');

// Check if the user is already logged in when the page loads
document.addEventListener('DOMContentLoaded', function () {
    // Check if the sessionStorage contains a "loggedIn" flag
    if (sessionStorage.getItem('loggedIn') === 'true') {
        // If logged in, show the logout button and hide the login button
        loginButton.style.display = 'none';
        logoutButton.style.display = 'inline';
    } else {
        // If not logged in, show the login button and hide the logout button
        loginButton.style.display = 'inline';
        logoutButton.style.display = 'none';
    }
});

// Event listener for the login button
loginButton.addEventListener('click', function (event) {
    event.preventDefault();  // Prevent form submission

    // Get user input from the form
    const username = usernameField.value.trim();  // Trim the input to remove whitespace
    const password = passwordField.value.trim();

    // Basic validation
    if (username === "" || password === "") {
        alert("Please enter both username and password.");
        return;
    }

    // Retrieve stored user credentials from localStorage
    const storedProfile = JSON.parse(localStorage.getItem("userProfile"));

    if (storedProfile && storedProfile.name === username && storedProfile.password === password) {
        // Store the logged-in state in sessionStorage
        sessionStorage.setItem('loggedIn', 'true');  // Mark as logged in
        alert("Login successful!");

        // Hide the login button and show the logout button
        loginButton.style.display = 'none';  // Hide login button
        logoutButton.style.display = 'inline';  // Show logout button

        // Optionally, reset the form fields after successful login
        usernameField.value = '';
        passwordField.value = '';

        // Redirect to website.html after successful login
        window.location.href = '../website.html';  // Redirect to the specified page
    } else {
        alert("Invalid username or password.");
    }
});

// Event listener for the logout button
logoutButton.addEventListener('click', function () {
    sessionStorage.removeItem('loggedIn');  // Remove session data
    alert("Logged out successfully.");

    // Hide the logout button and show the login button
    loginButton.style.display = 'inline';  // Show login button
    logoutButton.style.display = 'none';  // Hide logout button

    // Optionally, reset the form fields after logout
    usernameField.value = '';
    passwordField.value = '';
});
