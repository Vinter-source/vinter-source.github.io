// Add the mouse drag functionality to scroll the poems horizontally
let isDown = false;
let startX;
let scrollLeft;

const poemsWrapper = document.querySelector('.poems-wrapper');

// Mouse drag functionality for scrolling the poems
poemsWrapper.addEventListener('mousedown', (e) => {
    isDown = true;
    startX = e.pageX - poemsWrapper.offsetLeft;
    scrollLeft = poemsWrapper.scrollLeft;
    poemsWrapper.style.cursor = 'grabbing';  // Change cursor to grabbing
});

poemsWrapper.addEventListener('mouseleave', () => {
    isDown = false;
    poemsWrapper.style.cursor = 'grab';  // Reset cursor when mouse leaves
});

poemsWrapper.addEventListener('mouseup', () => {
    isDown = false;
    poemsWrapper.style.cursor = 'grab';  // Reset cursor on mouse up
});

poemsWrapper.addEventListener('mousemove', (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - poemsWrapper.offsetLeft;
    const walk = (x - startX) * 2; // Scroll speed factor
    poemsWrapper.scrollLeft = scrollLeft - walk;
});

document.addEventListener("DOMContentLoaded", function () {
    const poemsWrapper = document.querySelector('.poems-wrapper');
    const poems = document.querySelectorAll('.poem');
    
    // Pause scrolling animation when hovering over a poem
    poems.forEach(poem => {
        poem.addEventListener('mouseenter', function () {
            poemsWrapper.style.animationPlayState = 'paused';  // Pause animation
        });
        
        poem.addEventListener('mouseleave', function () {
            poemsWrapper.style.animationPlayState = 'running';  // Resume animation
        });
    });

    // Check if the user is logged in when the page loads
    checkLoginStatus();
});

// Check if the user is logged in and update the UI accordingly
function checkLoginStatus() {
    const profile = JSON.parse(localStorage.getItem("userProfile"));
    const logoutButton = document.getElementById("logoutButton");

    // Check if the user is logged in based on sessionStorage
    if (sessionStorage.getItem('loggedIn') === 'true' && profile) {
        // User is logged in, show the logout button
        logoutButton.style.display = 'inline-block';
    } else {
        // User is not logged in, hide the logout button and disable buttons
        logoutButton.style.display = 'none';
    }
}

// Redirect to signup or target page based on login status
function redirectToSignupOrPage(page) {
    if (sessionStorage.getItem('loggedIn') === 'true') {
        // If logged in, redirect to the specified page (either sendpoem.html or searchpoem.html)
        window.location.href = page;
    } else {
        // If the user is not logged in, redirect to the signup page
        window.location.href = "public/signup.html";  // Redirect to signup page
    }
}

// Add event listeners to the "Send Poem" and "Search Poem" buttons
document.getElementById("uploadBtn").addEventListener("click", function (e) {
    e.preventDefault();  // Prevent the default action (page navigation)
    redirectToSignupOrPage("public/sendpoem.html");  // Redirect to sendpoem.html if logged in
});

document.getElementById("browseBtn").addEventListener("click", function (e) {
    e.preventDefault();  // Prevent the default action (page navigation)
    redirectToSignupOrPage("public/searchpoem.html");  // Redirect to searchpoem.html if logged in
});

// Function to log the user out
function logout() {
    // Remove session storage to "log the user out"
    sessionStorage.removeItem('loggedIn');

    // Hide the logout button after logout
    document.getElementById("logoutButton").style.display = 'none';

    // Optionally, display a message or redirect to login page
    window.location.href = "public/log.html";  // Redirect to login page
}

// Attach the logout function to the logout button
document.getElementById("logoutButton").addEventListener("click", logout);
