// Function to toggle the visibility of the Services Section
function toggleServices() {
    const servicesSection = document.getElementById('servicesSection');
    const isHidden = servicesSection.style.display === 'none' || servicesSection.style.display === '';
    
    // Toggle the visibility
    if (isHidden) {
        servicesSection.style.display = 'block';
    } else {
        servicesSection.style.display = 'none';
    }
}

// Function to handle the button click event for "Submit Poem" and "Search Poem"
document.getElementById("submitPoemBtn").addEventListener("click", function() {
    // Redirect to the "submit poem" page
    window.location.href = "submitpoem.html";
});

document.getElementById("searchPoemBtn").addEventListener("click", function() {
    // Redirect to the "search poem" page
    window.location.href = "searchpoem.html";
});

// Optional: Add event listeners to buttons in the upload section
document.getElementById("uploadBtn").addEventListener("click", function() {
    window.location.href = "sendpoem.html"; // Redirect to Send Poem Page
});

document.getElementById("browseBtn").addEventListener("click", function() {
    window.location.href = "searchpoem.html"; // Redirect to Search Poem Page
});
