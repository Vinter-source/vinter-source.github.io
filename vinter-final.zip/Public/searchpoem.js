// Search Functionality
document.getElementById('searchInput').addEventListener('input', function() {
    const query = this.value.trim();  // Get the search query
    const recipientResultsContainer = document.getElementById('recipientResults');
    const noPoemsMessage = document.getElementById('noPoemsMessage');

    // Clear the previous results
    recipientResultsContainer.innerHTML = '';

    // Show/hide the no poems found message
    if (!query) {
        noPoemsMessage.style.display = 'none';  // Hide the message if the query is empty
        return;
    }

    // Get stored poems from localStorage
    const poems = getStoredPoems();

    // Filter poems based on the query for recipients only
    const recipientPoems = poems.filter(poem => {
        return poem.to && poem.to.toLowerCase().includes(query.toLowerCase());
    });

    // Display recipient poems
    if (recipientPoems.length > 0) {
        noPoemsMessage.style.display = 'none';  // Hide the no poems message if poems are found
        recipientPoems.forEach(poem => {
            const poemElement = createPoemElement(poem);
            recipientResultsContainer.appendChild(poemElement);
        });
    } else {
        // Display the "no poems found" message
        noPoemsMessage.style.display = 'block';
    }
});

// Function to create an HTML element for a poem
function createPoemElement(poem) {
    const poemElement = document.createElement('div');
    poemElement.classList.add('poem');
    poemElement.innerHTML = `
        <h3>${poem.title}</h3>
        <p><strong>To:</strong> ${poem.to}</p>
        <p><strong>Date:</strong> ${new Date(poem.id).toLocaleDateString()}</p>
        <div class="poem-content">
            <p>${poem.poem.slice(0, 150)}...</p>
        </div>
    `;

    // Add click event to show the full poem in a modal
    poemElement.addEventListener('click', () => {
        showModal(poem);
    });

    return poemElement;
}

// Function to retrieve stored poems from localStorage
function getStoredPoems() {
    const poems = JSON.parse(localStorage.getItem('poems')) || [];
    return poems;
}

// Function to show the modal with the full poem
function showModal(poem) {
    const modal = document.getElementById('poemModal');
    const modalContent = modal.querySelector('.modal-content');
    
    // Set content of modal
    modalContent.innerHTML = `
        <div class="modal-header">
            <h3>${poem.title}</h3>
            <span class="close" onclick="closeModal()">&times;</span>
        </div>
        <div class="modal-body">
            <p><strong>To:</strong> ${poem.to}</p>
            <p><strong>Date:</strong> ${new Date(poem.id).toLocaleDateString()}</p>
            <p>${poem.poem}</p>
        </div>
    `;

    // Show the modal
    modal.style.display = "block";
}

// Function to close the modal
function closeModal() {
    const modal = document.getElementById('poemModal');
    modal.style.display = "none";
}

// Close the modal if the user clicks outside of it
window.onclick = function(event) {
    const modal = document.getElementById('poemModal');
    if (event.target === modal) {
        closeModal();
    }
}
