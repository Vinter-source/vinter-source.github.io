const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Setup Gmail transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'vinter.sendapoem@gmail.com', // Your Gmail address
    pass: 'your-email-password' // Your Gmail password (or app-specific password)
  }
});

// POST route to send poem via email
app.post('/send-poem', (req, res) => {
  const { to, from, title, poem } = req.body;

  const mailOptions = {
    from: 'vinter.sendapoem@gmail.com', // Your Gmail address
    to: to, // Recipient's email address, passed from the request body
    subject: `Poem from ${from}: ${title}`, // Corrected string interpolation
    text: `From: ${from}\nTo: ${to}\nTitle: ${title}\n\n${poem}` // Corrected string interpolation
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error);
      res.status(500).send({ message: 'Failed to send the poem' });
    } else {
      console.log('Email sent: ' + info.response);
      res.status(200).send({ message: 'Poem sent successfully!' });
    }
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`); // Corrected console log
});
