// Validate the form before submission
function validateForm(event) {
    // Prevent the form from submitting (page reload) if validation is successful
    event.preventDefault();

    // Get form values
    const name = document.getElementById("name").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm_password").value;

    // Reset error messages
    document.getElementById("passwordError").innerText = "";
    document.getElementById("confirmPasswordError").innerText = "";

    let isValid = true;

    // Validate Password (Password must match and be at least 6 characters)
    if (password !== confirmPassword) {
        document.getElementById("confirmPasswordError").innerText = "Passwords do not match.";
        isValid = false;
    }
    if (password.length < 6) {
        document.getElementById("passwordError").innerText = "Password must be at least 6 characters.";
        isValid = false;
    }

    // If form is valid, save profile to localStorage and display it
    if (isValid) {
        saveProfile(name, password);
    }

    return isValid;
}

// Function to save profile in localStorage
function saveProfile(name, password) {
    const userProfile = { name, password };

    // Save the user profile to localStorage
    localStorage.setItem("userProfile", JSON.stringify(userProfile));

    // Set the logged-in state to true after the user profile is saved
    localStorage.setItem("isLoggedIn", "true");

    // Log the profile to verify
    console.log('Profile saved:', userProfile);

    // Redirect to the homepage after the profile is saved
    redirectToHomepage(name); // Call redirect function with the user's name
}

// Function to redirect to log in after sign up
function redirectToHomepage(name) {
    // Redirect to website.html
    window.location.href = "log.html";

    // Add a delay to show the popup after redirection (a few seconds)
    setTimeout(() => {
        showWelcomePopup(name);
    }, 1000); // Delay popup by 1 second to ensure page has loaded
}

// Function to display the "Welcome" popup after the redirect
function showWelcomePopup(name) {
    const popup = document.createElement("div");
    popup.id = "welcomePopup";
    popup.classList.add("popup");
    popup.innerText = `Welcome, ${name}!`;

    // Append the popup to the body
    document.body.appendChild(popup);

    // Set a timer to remove the popup after 4 seconds
    setTimeout(() => {
        popup.remove();
    }, 4000); // Remove after 4 seconds
}

// Optionally, add an event listener to the form submit button if needed
document.getElementById("signupForm").addEventListener("submit", validateForm);
